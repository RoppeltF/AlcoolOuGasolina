package br.pro.appherois_2020_1;

import androidx.annotation.NonNull;

public class Heroi {

    public int id;
    private String nome, grupo, result;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getGrupo() {
        return grupo;
    }

    public void setGrupo(String grupo) {
        this.grupo = grupo;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = String.valueOf(result);
    }

    @NonNull
    @Override
    public String toString() {
        return nome + " - " + grupo + " - " + result;
    }
}












